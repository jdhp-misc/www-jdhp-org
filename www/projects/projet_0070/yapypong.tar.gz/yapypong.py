#!/usr/bin/env python
# -*- coding: utf-8 -*-

# YapyPong (Yet Another PyPong) version 0.1
# This game is inspired by Julien Herbin's PyngPong

# Copyright (c) 2007 Jérémie Decock (http://www.jdhp.org)

# Permission to use, copy, modify, and distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.

# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import pygame, random, os
from pygame.locals import *

WIN_WIDTH = 800
WIN_HEIGHT = 600
PADDLE_WIDTH = 150
BALL_SPEED = 12
PADDLE_SPEED = 15
RIGHT_PLAYERS_KEY_UP = K_UP
RIGHT_PLAYERS_KEY_DOWN = K_DOWN
LEFT_PLAYERS_KEY_UP = K_s
LEFT_PLAYERS_KEY_DOWN = K_x

class Paddle(pygame.sprite.Sprite):
	def __init__(self, color, x_position):
		pygame.sprite.Sprite.__init__(self)
		self.image = pygame.Surface((20, PADDLE_WIDTH))
		self.image.fill(color);
		self.rect = self.image.get_rect()
		self.rect.topleft = (x_position, WIN_HEIGHT / 2 - PADDLE_WIDTH / 2)
		self.points = 0
	
	def init_position(self):
		self.rect.top = WIN_HEIGHT / 2 - PADDLE_WIDTH / 2

 	def moveUp(self):
		if self.rect.top - PADDLE_SPEED >= 0:
			self.rect = self.rect.move(0, -PADDLE_SPEED)
		else:
			self.rect.top = 0
	
	def moveDown(self):
		if self.rect.bottom + PADDLE_SPEED <= WIN_HEIGHT:
			self.rect = self.rect.move(0, PADDLE_SPEED)
		else:
			self.rect.top = WIN_HEIGHT - PADDLE_WIDTH
	
	def score(self):
		self.points += 1
	
	def getScore(self):
		return self.points

class Ball(pygame.sprite.Sprite):
	def __init__(self, start_position):
		pygame.sprite.Sprite.__init__(self)
		self.image = pygame.image.load(os.path.join('images', 'ball.png')).convert_alpha()
		self.rect = self.image.get_rect()
		self.rect.topleft = start_position
		temp = [-BALL_SPEED, BALL_SPEED]
		self.speed = [random.choice(temp), random.choice(temp)]	
	
	def update(self):
		self.rect = self.rect.move(self.speed)

def main():
	white = (255, 255, 255)

	pygame.init()
	clock = pygame.time.Clock()
	pygame.mouse.set_visible(False)

	# Window's configuration
	screen = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
	pygame.display.set_caption("YapyPong")
	pygame.display.set_icon(pygame.image.load(os.path.join('images', 'icon.png')).convert())
	background = pygame.image.load(os.path.join('images','fond.png')).convert()

	# Initialize sprites and fonts
	paddle_left = Paddle(white, 20)
	paddle_right = Paddle(white, WIN_WIDTH - 40)
	ball = Ball((WIN_WIDTH / 2, WIN_HEIGHT / 2))
	allsprites = pygame.sprite.RenderUpdates((paddle_left, paddle_right, ball))
	score_font = pygame.font.Font(None, 80)
	message_font = pygame.font.Font(None, 40)

	# Load sounds
	paddle_sound = pygame.mixer.Sound(os.path.join('sounds', 'paddle.ogg'))
	bounce_sound = pygame.mixer.Sound(os.path.join('sounds', 'bounce.ogg'))
	score_sound = pygame.mixer.Sound(os.path.join('sounds', 'score.ogg'))

	# Load and play music
	##pygame.mixer.music.load(os.path.join('sounds', 'music.ogg'))
	##pygame.mixer.music.play(-1)

	# Initialize game's flags
	game_started = False
	game_paused = False
	pause_key_already_active = False

	# Initialize mouse position information
	old_y_mouse_position = pygame.mouse.get_pos()[1]
	
	# Main loop
	while True:
		# Manage Pygame's events
		for event in pygame.event.get():
			if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
				pygame.display.quit()
				return
			
		# Manage user's events
		pressed_keys = pygame.key.get_pressed()
		
		if pressed_keys[K_f]:
			pygame.display.toggle_fullscreen()

		if pressed_keys[K_RETURN]:
			game_started = True

		if pressed_keys[K_p]:
			if game_started and not pause_key_already_active:
				game_paused = not game_paused
				pause_key_already_active = True # TODO : try a better way...
		else:
			pause_key_already_active = False

		if not game_started:
			message_value = "Press enter to start"
		elif game_paused:
			message_value = "Pause"
		else:
			message_value = ""

			# Left player control
			if pressed_keys[LEFT_PLAYERS_KEY_UP]:
				paddle_left.moveUp()
			if pressed_keys[LEFT_PLAYERS_KEY_DOWN]:
				paddle_left.moveDown()

			# Right player control
			if pressed_keys[RIGHT_PLAYERS_KEY_UP]:
				paddle_right.moveUp()
			if pressed_keys[RIGHT_PLAYERS_KEY_DOWN]:
				paddle_right.moveDown()
			
			# Ball's bounces
			if ball.rect.top < 0 or ball.rect.bottom > WIN_HEIGHT:
				ball.speed[1] = -ball.speed[1]
				bounce_sound.play()
			
			if ball.rect.left <= paddle_left.rect.right and ball.rect.left > paddle_left.rect.right - BALL_SPEED and ball.rect.top <= paddle_left.rect.bottom and ball.rect.bottom >= paddle_left.rect.top:
				ball.speed[0] = -ball.speed[0]
				paddle_sound.play()
			elif ball.rect.right >= paddle_right.rect.left and ball.rect.right < paddle_right.rect.left + BALL_SPEED and ball.rect.top <= paddle_right.rect.bottom and ball.rect.bottom >= paddle_right.rect.top:
				ball.speed[0] = -ball.speed[0]
				paddle_sound.play()

			# Score
			elif ball.rect.left < 0 :
				ball.__init__((WIN_WIDTH / 2, WIN_HEIGHT / 2))
				paddle_right.score()
				score_sound.play()
				paddle_left.init_position()
				paddle_right.init_position()
				game_started = False
			elif ball.rect.right > WIN_WIDTH:
				ball.__init__((WIN_WIDTH / 2, WIN_HEIGHT / 2))
				paddle_left.score()
				score_sound.play()
				paddle_left.init_position()
				paddle_right.init_position()
				game_started = False
			
			# Update all sprites
			allsprites.update()
		
		# Display texts
		score_panel = score_font.render(str(paddle_left.getScore()) + " : " + str(paddle_right.getScore()), 1, white)
		score_panel_position = score_panel.get_rect(centerx=(WIN_WIDTH / 2))
		message = message_font.render(message_value, 1, white)
		message_position = message.get_rect(center=(WIN_WIDTH / 2, WIN_HEIGHT / 2 - 64))
		
		# Control the framerate of the game (60 fps max)
		clock.tick(60) 

		# Display all
		screen.blit(background, (0, 0))
		screen.blit(score_panel, score_panel_position)
		allsprites.draw(screen)
		screen.blit(message, message_position)
		pygame.display.flip()

	pygame.mixer.music.fadeout()

if __name__ == '__main__':
	main()
